A fully working example for this module is available on github at https://github.com/acktie/Acktie-Mobile-Barcode-Example

Tony Nuzzi @ Acktie

Twitter: @Acktie

Email: support@acktie.com